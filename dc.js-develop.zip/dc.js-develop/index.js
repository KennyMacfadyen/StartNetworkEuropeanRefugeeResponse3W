// Import DC and dependencies

d3 = require("d3");
crossfilter = require("crossfilter");
module.exports = require("./dc");
