# dc.js

Welcome to the dc.js documentation.

The entire library is scoped under {@link dc the dc namespace}.

The other Namespaces contain utilities.

The charts are listed under Classes.

And shared chart functionality is under Mixins.
